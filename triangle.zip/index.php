<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Bitspay | Home</title>
   
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet"> 
    <link href="css/lightbox.css" rel="stylesheet"> 
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <link href="css/bootstrap-select.css" rel="stylesheet">

    <!--[if lt IE 9]>
	    <script src="js/html5shiv.js"></script>
	    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
  
    
     

  <script src="https://code.jquery.com/jquery-3.2.1.slim.js" defer></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js" defer></script>
      <script src="js/bootstrap-select.js"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.7.5/js/bootstrap-select.min.js"></script>
      
    <!-- for auto sliding testimonial section -->
    <style>
    .carousel-indicators .active{ background: #33f999; } .content{ margin-top:20px; } .adjust1{ float:left; width:100%; margin-bottom:0; } .adjust2{ margin:0; }  .carousel-control{ color:#33f999; width:5%; } .carousel-control:hover, .carousel-control:focus{ color:#33f999; } .carousel-control.left, .carousel-control.right { background-image: none; } .media-object{ margin:auto; margin-top:15%; } @media screen and (max-width: 768px) { .media-object{ margin-top:0; } }
    </style>
    
    <!-- for parallax  -->
    
   <style>
.parallax { 
    /* The image used */
    background-image: url("images/background.jpg");

    /* Set a specific height */
    height: 500px; 

    /* Create the parallax scrolling effect */
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
</style>
    
    <style>
::placeholder {
    color: #33f999;
    opacity: 0.7; /* Firefox */
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
   color: #33f999;
}

::-ms-input-placeholder { /* Microsoft Edge */
   color: #33f999;
}
</style>

    
</head><!--/head-->

<body>
	<header id="header">      
        <div class="container">
            <div class="row">
                <div class="col-sm-12 overflow">
                   <div class="social-icons pull-right">
                        <ul class="nav nav-pills">
                            <li><a href=""><i class="fa fa-facebook"></i></a></li>
                            <li><a href=""><i class="fa fa-twitter"></i></a></li>
                            <li><a href=""><i class="fa fa-google-plus"></i></a></li>
                            <li><a href=""><i class="fa fa-dribbble"></i></a></li>
                            <li><a href=""><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div> 
                </div>
             </div>
        </div>
        <div class="navbar navbar-inverse " role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <a class="navbar-brand" href="index.php">
                    	<h1><img src="images/logo.png" alt="logo"></h1>
                    </a>
                    
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="index.php">Home</a></li>
                        <!--<li class="dropdown"><a href="#">Pages <i class="fa fa-angle-down"></i></a>
                            <ul role="menu" class="sub-menu">
                                <li><a href="aboutus.html">About</a></li>
                                <li><a href="aboutus2.html">About 2</a></li>
                                <li><a href="service.html">Services</a></li>
                                <li><a href="pricing.html">Pricing</a></li>
                                <li><a href="contact.html">Contact us</a></li>
                                <li><a href="contact2.html">Contact us 2</a></li>
                                <li><a href="404.html">404 error</a></li>
                                <li><a href="coming-soon.html">Coming Soon</a></li>
                            </ul>
                        </li>                    
                        <li class="dropdown"><a href="blog.html">Blog <i class="fa fa-angle-down"></i></a>
                            <ul role="menu" class="sub-menu">
                                <li><a href="blog.html">Blog Default</a></li>
                                <li><a href="blogtwo.html">Timeline Blog</a></li>
                                <li><a href="blogone.html">2 Columns + Right Sidebar</a></li>
                                <li><a href="blogthree.html">1 Column + Left Sidebar</a></li>
                                <li><a href="blogfour.html">Blog Masonary</a></li>
                                <li><a href="blogdetails.html">Blog Details</a></li>
                            </ul>
                        </li>
                        <li class="dropdown"><a href="portfolio.html">Portfolio <i class="fa fa-angle-down"></i></a>
                            <ul role="menu" class="sub-menu">
                                <li><a href="portfolio.html">Portfolio Default</a></li>
                                <li><a href="portfoliofour.html">Isotope 3 Columns + Right Sidebar</a></li>
                                <li><a href="portfolioone.html">3 Columns + Right Sidebar</a></li>
                                <li><a href="portfoliotwo.html">3 Columns + Left Sidebar</a></li>
                                <li><a href="portfoliothree.html">2 Columns</a></li>
                                <li><a href="portfolio-details.html">Portfolio Details</a></li>
                            </ul>
                        </li> -->                        
                        <li><a href="exchange_data.php">Exchange Data</a></li>                    
                         <li><a href="aboutus2.html">About Us</a></li>                    
                    </ul>
                </div>
                <div class="search">
                    <form role="form">
                        <i class="fa fa-search"></i>
                        <div class="field-toggle">
                            <input type="text" class="search-form" autocomplete="off" placeholder="Search">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </header>
    <!--/#header-->

    <section id="home-slider">
        <div class="container">
            <div class="row">
                <div class="main-slider">
                    <div class="slide-text">
                        <h2 class="">Convenient & Secure Cryptocurrency Exchange</h2><hr>
                        <p>Direct cryptocurrency transactions, instant exchange between different currencies. Accessible 24/7 worldwide on your laptop, desktop or mobile devices alike.

</p><hr>
                        <a href="#" class="btn btn-common" >SIGN UP</a>
                    </div>
                     
                    <img src="images/home/slider/hill.png" style="width: 35%" class="slider-hill" alt="slider image">
                   
                    <!--<img src="images/home/slider/house.png" class="slider-house" alt="slider image">
                    <img src="images/home/slider/sun.png" class="slider-sun" alt="slider image">-->
                    <img src="https://bitcoin.org/img/icons/opengraph.png" class="slider-birds1 w3-hide-small" alt="slider image" style="width: 3%">
                    <img src="https://png.icons8.com/color/1600/ethereum.png" class="slider-birds2 w3-hide-small" alt="slider image" style="width: 3%">
                    <img src="https://new.innovatefinance.com/wp-content/uploads/2017/10/ripple_logo_mark.png" class="slider-birds3 w3-hide-small" alt="slider image" style="width: 3%">
                    <img src="http://getcoin.site/dashcoin/DASH.png" class="slider-birds4 w3-hide-small" alt="slider image" style="width: 3%">
                    <img src="https://getmonero.org/press-kit/symbols/monero-symbol-480.png" class=" w3-hide-small" class="slider-birds5" alt="slider image" style="width: 3%">
                </div>
            </div>
        </div>
        <div class="preloader"><i class="fa fa-sun-o fa-spin"></i></div>
    </section>
    <!--/#home-slider-->
    <section style="margin-top: 50px">
        <div class="container">
            <div class="row  w3-margin " >
                <div class="row-md-12">
                 <h2 style="color: #33f999 " class="w3-center">THE BEST BITCOIN EXCHANGE</h2>
                    <p class="w3-xlarge" style="color: #818285 ">The best bitcoin exchange is needed for serious and professional bitcoin traders. Bitcoin security must be impeccable. Banking relationships must be sound and reliable. The trading engine must be fast. Order types must be advanced. And profits must be able to be multiplied with Bitcoin margin trading so you can leverage long bitcoin positions or short bitcoin positions.</p>
                </div>
            </div>
        </div>
    </section>
    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 text-center padding wow fadeIn" data-wow-duration="1000ms" data-wow-delay="300ms">
                    <div class="single-service">
                        <div class="wow scaleIn" data-wow-duration="500ms" data-wow-delay="300ms">
                             <img src="images/home/liquidity.png" alt="">
                        </div>
                        <h2>Liquidity</h2>
                        <p>Ground round tenderloin flank shank ribeye. Hamkevin meatball swine. Cow shankle beef sirloin chicken ground round.</p>
                    </div>
                </div>
                 <div class="col-sm-4 text-center padding wow fadeIn" data-wow-duration="1000ms" data-wow-delay="900ms">
                    <div class="single-service">
                        <div class="wow scaleIn" data-wow-duration="500ms" data-wow-delay="900ms">
                            <img src="images/home/fastest_trading.png" alt="">
                        </div>
                        <h2>Fastest Trading Platform</h2>
                        <p>Venison tongue, salami corned beef ball tip meatloaf bacon. Fatback pork belly bresaola tenderloin bone pork kevin shankle.</p>
                    </div>
                </div>
                <div class="col-sm-4 text-center padding wow fadeIn" data-wow-duration="1000ms" data-wow-delay="600ms">
                    <div class="single-service">
                        <div class="wow scaleIn" data-wow-duration="500ms" data-wow-delay="600ms">
                            <img src="images/home/reliability.png" alt="">
                        </div>
                        <h2>Reliability</h2>
                        <p>Hamburger ribeye drumstick turkey, strip steak sausage ground round shank pastrami beef brisket pancetta venison.</p>
                    </div>
                </div>
               
            </div>
        </div>
    </section>
    <!--/#services-->
  

    <!--<section id="action" class="responsive">
        <div class="vertical-center">
             <div class="container">
                <div class="row">
                    <div class="action take-tour">
                        <div class="col-sm-7 wow fadeInLeft" data-wow-duration="500ms" data-wow-delay="300ms">
                            <h1 class="title">Triangle Corporate Template</h1>
                            <p>A responsive, retina-ready &amp; wide multipurpose template.</p>
                        </div>
                        <div class="col-sm-5 text-center wow fadeInRight" data-wow-duration="500ms" data-wow-delay="300ms">
                            <div class="tour-button">
                                <a href="#" class="btn btn-common">TAKE THE TOUR</a>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   </section>-->
    <!--/#action-->
    <div class="parallax">
    <section id="features"  class="w3-text-white" >
        <div class="container">
            <div class="row">
                
                
                <div class="single-features">
                    <div class="col-md-6 wow fadeInLeft" data-wow-duration="500ms" data-wow-delay="300ms">
                        <img src="images/home/bitcoin.png" class="img-responsive" alt="">
                    </div>
                    <div class="col-md-6 wow fadeInRight" data-wow-duration="500ms" data-wow-delay="300ms">
                         <h2  class="w3-text-white">Multi-currency account</h2>
                        <P class="">Manage different cryptocurrencies in one personal account. Securely store, easily receive and quickly send Bitcoin, Litecoin, Dash, Zcash and other digital currencies.</P>
                    </div>
                </div>
                <div class="single-features">
                    <div class="col-md-6 align-right wow fadeInLeft" data-wow-duration="500ms" data-wow-delay="300ms">
                       <h2 class="w3-text-white">Anonymous & secure</h2>
                       <P class="w3-left">Bank-grade security and next generation account protection. Encrypted SSL connection over HTTPS, 2-factor authentication and trusted IPs. No questions asked.</P>
                    </div>
                    <div class="col-md-6 wow fadeInRight" data-wow-duration="500ms" data-wow-delay="300ms">
                         <img src="images/home/security.png" class="img-responsive" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>
     <!--/#features-->
      <section>
        <div class="container ">
            <div class="row w3-center"> 
                <h1 class="w3-padding w3-margin-bottom">Exchange cryptocurrency
</h1>
                <div class="form-group col-md-12" style="padding: 10px 15% 10px 15%">
                        <div class="col-md-6 w3-margin">
                            
                            <input class="form-control input-md" id="amt_coin_from" type="number" placeholder="YOU HAVE" oninput="currencyConverter(this.value)" onchange="currencyConverter(this.value)">
                          </div>
                    <div class="col-md-4 w3-margin">
                              <select id="coin_from" class="selectpicker"  data-live-search="true">

                <optgroup label="Cryptocurrency" >
                  <option>Bitcoin</option>
                  <option>Ethereum</option>
                      <option>Ripple</option>
                      <option>Litecoin</option>
                      <option>Monero</option>
                      <option>Dashcoin</option>
                      
                </optgroup>
                <optgroup label="Fiat Currency">
                  <option>US Dollor</option>
                  <option>Euro</option>
                    <option>Indian Rupee</option>
                    <option>Japanese Yen</option>
                </optgroup>
              </select>
                        </div>
                    <div class="col-md-6 w3-margin">
                            
                            <input class="form-control input-md" id="amt_coin_to" type="text" placeholder="YOU GET" disabled>
                          </div>
                    <div class="col-md-4 w3-margin">
                              <select id="coin_to" class="selectpicker"  data-live-search="true" >

               <optgroup label="Cryptocurrency">
                  <option>Bitcoin</option>
                  <option>Ethereum</option>
                      <option>Ripple</option>
                      <option>Litecoin</option>
                      <option>Monero</option>
                      <option>Dashcoin</option>
                      
                </optgroup>
                <optgroup label="Fiat Currency">
                  <option>US Dollor</option>
                  <option>Euro</option>
                    <option>Indian Rupee</option>
                    <option>Japanese Yen</option>
                </optgroup>
              </select>
                        </div>
                </div>
            
            </div>
        
        </div>
    </section>
   
    <section id="clients">
        <div class="container" >
            <div class="row">
                <div class="col-sm-12">
                    <div class="clients text-center wow fadeInUp" style="margin-top: 50px" data-wow-duration="500ms" data-wow-delay="300ms">
                       
                        <h1 class=" ">Cryptocurrency we support</h1>
                        
                    </div>
                    <div class="clients-logo wow fadeIn" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="col-xs-3 col-sm-2">
                            <a href="#"><img src="images/bitcoin.png" class="img-responsive" alt=""></a>
                        </div>
                        <div class="col-xs-3 col-sm-2">
                            <a href="#"><img src="images/ethereum.png" class="img-responsive" alt=""></a>
                        </div>
                         <div class="col-xs-3 col-sm-2">
                            <a href="#"><img src="images/ripple.png" class="img-responsive" alt=""></a>
                        </div>
                         <div class="col-xs-3 col-sm-2">
                            <a href="#"><img src="images/dashcoin.png" class="img-responsive" alt=""></a>
                        </div>
                         <div class="col-xs-3 col-sm-2">
                            <a href="#"><img src="images/monero.png" class="img-responsive" alt=""></a>
                        </div>
                         <div class="col-xs-3 col-sm-2">
                            <a href="#"><img src="images/litecoin.png" class="img-responsive" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     </section>
    <!--/#clients-->
    <!--<section class=" w3-padding">
    <div class="container content">
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel"> 
            <ol class="carousel-indicators"> 
                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li> 
                <li data-target="#carousel-example-generic" data-slide-to="1"></li> 
                <li data-target="#carousel-example-generic" data-slide-to="2"></li> 
            </ol> 
    <div class="carousel-inner">
        <div class="item active"> 
            <div class="row"> 
                <div class="col-xs-12"> 
                    <div class="thumbnail adjust1"> 
                        <div class="col-md-2 col-sm-2 col-xs-12"> 
                            <img class="media-object img-rounded img-responsive" src="http://placehold.it/100"> 
                        </div> 
                        <div class="col-md-10 col-sm-10 col-xs-12">
                            <div class="caption"> 
                                <p class="text-info lead adjust2" style="color: #33f999">I can't wait to test this out.</p>
                                <p><span class="glyphicon glyphicon-thumbs-up"></span> This is a testimonial window. Feedback of user can be displayed here.</p>
                                <blockquote class="adjust2"> <p>Abhijit Goswami</p>
                                    <small><cite title="Source Title"><i class="glyphicon glyphicon-globe"></i> www.example1.com</cite></small>
                                </blockquote>
                            </div> 
                        </div> 
                    </div> 
                </div> 
            </div> 
            </div>
            <div class="item"> 
                <div class="row"> 
                    <div class="col-xs-12"> 
                        <div class="thumbnail adjust1">
                            <div class="col-md-2 col-sm-2 col-xs-12"> 
                                <img class="media-object img-rounded img-responsive" src="http://placehold.it/100"> 
                            </div> 
                            <div class="col-md-10 col-sm-10 col-xs-12"> 
                                <div class="caption"> 
                                    <p class="text-info lead adjust2">I can't wait to test this out.</p> 
                                    <p><span class="glyphicon glyphicon-thumbs-up"></span> This is a testimonial window. Feedback of user can be displayed here.</p> 
                                    <blockquote class="adjust2"> <p>Abhijit Goswami</p> <small><cite title="Source Title"><i class="glyphicon glyphicon-globe"></i> www.example2.com</cite></small> </blockquote>
                                </div> 
                            </div> 
                        </div>
                    </div> 
                </div> 
            </div> 
            <div class="item"> 
                <div class="row"> 
                    <div class="col-xs-12"> 
                        <div class="thumbnail adjust1">
                            <div class="col-md-2 col-sm-2 col-xs-12"> 
                                <img class="media-object img-rounded img-responsive" src="http://placehold.it/100"> 
                            </div> 
                            <div class="col-md-10 col-sm-10 col-xs-12"> 
                                <div class="caption"> 
                                    <p class="text-info lead adjust2">I can't wait to test this out.</p> 
                                    <p><span class="glyphicon glyphicon-thumbs-up"></span> This is a testimonial window. Feedback of user can be displayed here.</p> 
                                    <blockquote class="adjust2"> <p>Abhijit Goswami</p> <small><cite title="Source Title"><i class="glyphicon glyphicon-globe"></i> www.example2.com</cite></small> </blockquote>
                                </div> 
                            </div> 
                        </div>
                    </div> 
                </div> 
            </div> 
            </div> 
            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span> </a>
            <a class="right carousel-control" href="#carousel-example-generic" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span> </a>
            
        </div> 
        </div>
    </section> -->
    
     <section id=""  class="w3-text-white " style="background-color: #33f999;  ">
        <div class="container"  >
            <div class="row">
                
                
                <div class=" col-md-8" style="padding: 30px">
                   <h2 class="w3-text-white">Create an account to start trading</h2>
                    <h4>bitPay offers institutions and professionals the ability to trade a variety of digital currencies like Bitcoin, Ethereum .

                    </h4>
                </div>
                <div class="col-md-4 single-features w3-center  " style="margin-top: 30px"><br><br>  
                    <a href="" class="btn btn-default w3-round-xlarge w3-large  w3-padding " style="color: #33f999; box-shadow: 3px 5px 12px 0px rgba(0, 121, 62, 0.3); ">Create Account</a>
                </div>
              
            </div>
        </div>
    </section>
       
    <footer id="footer">
        <div class="container w3-margin-top">
            <div class="row">
               
                <div class="col-md-4 col-sm-6">
                    <div class="testimonial bottom">
                        <h2>Testimonial</h2>
                        <div class="media">
                            <div class="pull-left">
                                
                            </div>
                            <div class="media-body">
                                <blockquote>The ability to create something
that is not duplicable in the digital world
has enormous value
</blockquote>
                                <h3><a href="#">- Jhon Kalis</a></h3>
                            </div>
                         </div>
                        <div class="media">
                            <div class="pull-left">
                                
                            </div>
                            <div class="media-body">
                                <blockquote>For people who can afford to
invest a little in cryptocurrency,
it’s worth looking into.</blockquote>
                                <h3><a href="">- Abraham Josef</a></h3>
                            </div>
                        </div>   
                    </div> 
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="contact-info bottom">
                        <h2>Contacts</h2>
                        <address>
                        E-mail: <a href="mailto:support@bitspay.co">support@bitspay.co</a> <br> 
                        Phone: +1 (123) 456 7890 <br> 
                        Fax: +1 (123) 456 7891 <br> 
                        </address>

                        <h2>Address</h2>
                        <address>
                        Unit C2, St.Vincent's Trading Est., <br> 
                        Feeder Road, <br> 
                        Bristol, BS2 0UY <br> 
                        United Kingdom <br> 
                        </address>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="contact-form bottom">
                        <h2>Send a message</h2>
                        <form id="main-contact-form" name="contact-form" method="post" action="sendemail.php">
                            <div class="form-group">
                                <input type="text" name="name" class="form-control" required="required" placeholder="Name">
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" class="form-control" required="required" placeholder="Email Id">
                            </div>
                            <div class="form-group">
                                <textarea name="message" id="message" required="required" class="form-control" rows="8" placeholder="Your text here"></textarea>
                            </div>                        
                            <div class="form-group">
                                <input type="submit" name="submit" class="btn btn-submit" value="Submit">
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="copyright-text text-center w3-text-dark-grey" >
                        <p>&copy; 2018 Bitspay. All Rights Reserved.</p>
                        
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--/#footer-->

    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/lightbox.min.js"></script>
    <script type="text/javascript" src="js/wow.min.js"></script>
    <script type="text/javascript" src="js/main.js"></script>   
    
    <!-- for auto sliding testimonail section -->
    <script>
    $(document).ready(function() {
  //carousel options
  $('#carousel-example-generic').carousel({
    pause: true, interval: 3000,
  });
});
    </script>
    <script>
function currencyConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("amt_coin_to").value=(valNum-32)/1.8;
}
</script>
</body>
</html>
