<?php

	session_start();
	 
	 
	 if(isset($_POST['register'])){
	 
	 	$name = $_POST['name'];
	 	$email = $_POST['email'];
	 	$phone = $_POST['phone'];
	 	$password = $_POST['password'];
	 	
	 
	 	
	 	$otp =  mt_rand(100000, 999999);
	 	

	 	 $_SESSION["otp"] = $otp; 
	 	 
                   /* $to      = $email;
                    $subject = 'OTP for activating your account';
                    
                   
                    $message = "<html>
				<body>
				
				<h4>Thank you for connecting with us </h4>
				<p>The <b>One Time Password</b> for signing in to your account is <b>".$a."<b><br> Dont share this with anyone else </p>
				
				</body>
				</html>
				";
                    $headers = 'MIME-Version: 1.0'."\r\n";
		    $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
		    $headers .= 'From: support@fxcoin.uk' . "\r\n" .
                       'Reply-To: support@fxcoin.uk';
                   
                   mail($to, $subject, $message, $headers);  */
                   
                   
	 	
	 	
	 
	 }

?>




<!DOCTYPE html>
<html lang="en">
<head>
<title>Fashion Club an Ecommerce Online Shopping Category  Flat Bootstrap responsive Website Template | Register :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Fashion Club Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" media="all" />
<!--// css -->
<!-- font -->
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //font -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
</head>
<body>
<!---728x90--->
<div class="header-top-w3layouts">
	<div class="container">
		<div class="col-md-6 logo-w3">
			<a href="index-2.html"><img src="images/logo2.png" alt=" " /><h1>FASHION<span>CLUB</span></h1></a>
		</div>
		<div class="col-md-6 phone-w3l">
			<ul>
				<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span></li>
				<li>+18045403380</li>
			</ul>
		</div>
		<div class="clearfix"></div>
	</div>
</div>


<div class="login">
	
		<div class="main-agileits">
				<div class="form-w3agile">
					<p style="font-size: 21px; text-align: center; ">Confirm you Email-ID</p>
					<form action="validate_otp.php" method="post">
					<?php echo $_SESSION["otp"]; ?>
						<p style="margin: 20px">We have successfully sent an otp to your registered email account . Please enter that otp to confirm that <?php echo $_SESSION['email'] ?>  belongs to you.<p>
						<div class="key">
							<i class="fa fa-lock" aria-hidden="true"></i>
							<input  type="text"  name="entered_otp"  required=""  placeholder="Enter OTP here">
							<input  type="hidden"  name="name">
							<input  type="hidden"  name="email">
							<input  type="hidden"  name="phone">
							<input  type="hidden"  name="password">
							<div class="clearfix"></div>
						</div>
						<input type="submit" value="Validate OTP" name="validate_otp">
					</form>
				</div>
			</div>
		</div>
</div>
	
	

	
</body>

<!-- Mirrored from p.w3layouts.com/demos/sep-2016/15-09-2016/fashion_club/web/register.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 01 Apr 2018 16:18:03 GMT -->
</html>

