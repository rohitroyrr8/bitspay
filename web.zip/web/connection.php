<?php
$servername = "108.170.8.242";
$username = "shopchun_root";
$password = "Shopchun@123";
$dbname = "shopchun_store";

// Create connection
$connection = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
} 


?>