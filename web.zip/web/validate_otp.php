<?php
session_start();
	 
	 
	 if(isset($_POST['validate_otp'])){
	 
	 
	 
	 	$entered_otp = $_POST["entered_otp"];
	 	
	 	
	 	if($entered_top = $_SESSION["otp"]){
	 		
                            unset($_SESSION["otp"]);
                            
                            require('connection.php');
                            
                            $username= $_POST["name"];
                            
                            $phone= $_POST["phone"];
                            $email= $_POST["email"];
                            $password= $_POST["password"];
                            
                            $current_date = date("Y-m-d");
                            
                            $sql = "INSERT INTO users (user_id, name, phone, email, password, date_creation)
                            VALUES ('$entered_otp','$name', '$phone', '$email', '$password', '$current_date' );";
                            
                            
                            if ($connection->query($sql) === TRUE) {
                            
                            	echo "Done";
                            
                            }
                            
                            else{
                            
                            	echo $connection->error;
                            }
	 	}
	 	else{
	 		echo "Incorrect OTP";
	 	}


	}

?>